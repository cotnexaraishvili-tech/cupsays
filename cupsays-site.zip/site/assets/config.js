// ===== SITE SETTINGS =====
// adsenseClient: after Google AdSense approves your site, put your publisher ID here, e.g. "ca-pub-1234567890123456".
//                Leave it empty ("") until then: no ads and no ad scripts will load.
// adSlot:        optional. The ID of a display ad unit (a long number) if you want manual ad units on article pages.
//                Leave empty to use only Auto ads configured inside AdSense.
// wait:          waiting time before the reading is written, in seconds (80 = 1 min 20 s). The page spends this time in two steps.
// cps:           characters per second while the reading is being written.
window.SITE_CONFIG={adsenseClient:"",adSlot:"",wait:80,cps:7};

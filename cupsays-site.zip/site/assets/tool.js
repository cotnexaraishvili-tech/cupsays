(function(){
  var D=window.FINCANI,C=window.SITE_CONFIG||{};
  var root=document.getElementById("tool");
  if(!D||!root)return;
  var WAIT=C.wait||80,CPS=C.cps||7;
  var $=function(id){return document.getElementById(id)};
  var pick=function(a){return a[Math.floor(Math.random()*a.length)]};
  var sleep=function(ms){return new Promise(function(r){setTimeout(r,ms)})};
  var fill=function(s,o){for(var k in o)s=s.replace("{"+k+"}",o[k]);return s};
  var topic="general",nPhotos=0,busy=false,urls=[];
  var reader=pick(D.readers);
  $("online").textContent=fill(D.ui.online,{r:reader});

  var tb=$("topics");
  [].forEach.call(tb.querySelectorAll("button"),function(b){
    b.addEventListener("click",function(){
      topic=b.getAttribute("data-topic");
      [].forEach.call(tb.querySelectorAll("button"),function(c){
        var on=c===b;c.className=on?"on":"";c.setAttribute("aria-pressed",on?"true":"false");
      });
    });
  });

  $("file").addEventListener("change",function(e){
    urls.forEach(function(u){URL.revokeObjectURL(u)});urls=[];
    var th=$("thumbs");th.innerHTML="";
    var fs=[].slice.call(e.target.files).slice(0,4);nPhotos=fs.length;
    fs.forEach(function(f){
      var u=URL.createObjectURL(f);urls.push(u);
      var i=document.createElement("img");i.src=u;i.alt="";th.appendChild(i);
    });
    $("dropT").textContent=nPhotos?fill(D.ui.dropN,{n:nPhotos}):D.ui.drop;
  });

  function build(nm){
    var ss=D.sym.slice().sort(function(){return Math.random()-.5}).slice(0,3);
    var p1=(nm?nm+", ":"")+pick(D.op);
    var p2=ss.map(function(x){return pick(D.fr).replace("{n}",x[0]).replace("{t}",x[1])}).join("\n");
    var p3=D.topics[topic].slice().sort(function(){return Math.random()-.5}).slice(0,2).join(" ");
    return [p1,p2,p3+" "+pick(D.en)].join("\n\n");
  }

  $("go").addEventListener("click",async function(){
    if(busy)return;
    var go=$("go"),out=$("out"),card=$("outCard");
    var say=function(t){card.hidden=false;out.textContent=t;};
    busy=true;go.disabled=true;go.textContent=fill(D.ui.reading,{r:reader});
    say(fill(D.ui.look,{r:reader}));await sleep(WAIT*500);
    say(fill(D.ui.study,{r:reader}));await sleep(WAIT*500);
    var text=build($("name").value.trim()),sh="";
    var chars=Array.from(text);
    for(var i=0;i<chars.length;i++){
      var ch=chars[i];sh+=ch;
      out.textContent=fill(D.ui.writing,{r:reader})+"\n\n"+sh+"▌";
      await sleep(1000/CPS*(.5+Math.random())+(/[.!?\n]/.test(ch)?300+Math.random()*500:0));
    }
    out.textContent="— "+reader+"\n\n"+text;
    busy=false;go.disabled=false;go.textContent=go.getAttribute("data-label");
  });
})();

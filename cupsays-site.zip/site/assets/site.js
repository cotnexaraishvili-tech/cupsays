// Loads Google AdSense only when a publisher ID is set in config.js.
(function(){
  var C=window.SITE_CONFIG||{};
  if(!C.adsenseClient)return;
  var s=document.createElement("script");
  s.async=true;s.crossOrigin="anonymous";
  s.src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client="+encodeURIComponent(C.adsenseClient);
  document.head.appendChild(s);
  if(!C.adSlot)return;
  document.querySelectorAll(".ad-slot").forEach(function(box){
    var ins=document.createElement("ins");
    ins.className="adsbygoogle";ins.style.display="block";
    ins.setAttribute("data-ad-client",C.adsenseClient);
    ins.setAttribute("data-ad-slot",C.adSlot);
    ins.setAttribute("data-ad-format","auto");
    ins.setAttribute("data-full-width-responsive","true");
    box.appendChild(ins);
    try{(window.adsbygoogle=window.adsbygoogle||[]).push({});}catch(e){}
  });
})();
